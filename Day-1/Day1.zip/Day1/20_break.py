for val in  "string":
    if  val ==  "i":
        break
    print(val)
print("The end")