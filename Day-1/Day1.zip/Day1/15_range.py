import os
os.system('cls')
print(list(range(10)))
print(list(range(0, 10)))
print(list(range(2,8)))
print(list(range(2,20,3)))