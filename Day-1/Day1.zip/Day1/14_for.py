numbers = [6,5,3,8,4,2,5,4,11]
# variable to store the sum
sum = 0
# iterate over the list
for val in  numbers:
    sum = sum+val
# print the sum
print("The sum is",sum)