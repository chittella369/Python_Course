# In this program, user inputs a number.
# If the number is positive, we print an appropriate message
num = float(input("Enter a number: "))
if num > 0:
    print("Positive number")
    print("This is always printed")