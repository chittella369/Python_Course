name = input("Enter Your Name: ")
print ("Your Name is = "+name)
age = input("Enter Your Age:")
print("So, you are already " + age + " years old, " + name + "!")