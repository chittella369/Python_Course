import os
os.system('cls')
c1 = complex(2,3)
print("Complex no C1 = "+str(c1))
print("Real Part = "+str(c1.real))
print("Imaginary Part= "+str(c1.imag))
print("Conjugate = "+str(c1.conjugate()))