# In this program, user input a number
# Program check if the number is positive or negative and display an appropriate message
num = float(input("Enter a number: "))
if num >= 0:
    print("Positive or Zero")
else:
    print("Negative number")