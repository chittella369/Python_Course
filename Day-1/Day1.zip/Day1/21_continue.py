# Program to show the #use of continue
# statement inside loops
for val in  "Accenture":
    if  val ==  'n':
        continue
    print(val)
print("The end")