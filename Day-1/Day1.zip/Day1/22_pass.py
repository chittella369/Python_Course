sequence=[1,2,3]
for val in  sequence:
    pass