import os
os.system('cls')
myint= 7
myfloat1 = 7.65
myfloat2 = float(7.9265)
print("MyInt= "+str(myint))
print("MyFloat1 = "+str(myfloat1))
print("MyFloat2 = "+str(myfloat2))