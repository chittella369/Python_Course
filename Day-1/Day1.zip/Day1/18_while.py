# Program to print n natural numbers
# take input from the user
n = int(input("Enter n: "))
i= 1
while   i<= n:
    print (" ",i)
    i= i+1