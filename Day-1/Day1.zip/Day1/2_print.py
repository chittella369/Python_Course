import os
os.system('cls')
print ("=========== Welcome to Python World....==============")
print("Hello World")
print("Hello World !!!"+" Welcome to Accenture....")
print("\n\n\n")
print("================== Good Day....=====================")