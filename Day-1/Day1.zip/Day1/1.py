import os
os.system('cls')
print("Hello World")
print("Welcome to Accenture....")