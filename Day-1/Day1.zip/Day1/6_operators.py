x = 15
y = 4
print('x + y = ',x+y)
print('x -y = ',x-y)
print('x * y = ',x*y)
print('x / y = ',x/y)
print('x // y = ',x//y)
print('x ** y = ',x**y)