x = True
y = False
print('x and y is',x and y)
print('x or y is',x or y)
print('not x is',not x)